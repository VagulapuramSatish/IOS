//
//  ViewController.swift
//  WordGuess
//
//  Created by Vagulapuram,Satish on 2/22/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DisplayLabel: UILabel!
    
    @IBOutlet weak var HintLabel: UILabel!
    
    @IBOutlet weak var letterEntered: UITextField!
    
    @IBOutlet weak var CheckButton: UIButton!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var PlayAgainButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func CheckButtonClicked(_ sender: Any) {
    }
    
    
    @IBAction func PlayAgainButtonClicked(_ sender: UIButton) {
    }
    
    @IBAction func enterLabelChanged(_ sender: UITextField) {
    }
}

