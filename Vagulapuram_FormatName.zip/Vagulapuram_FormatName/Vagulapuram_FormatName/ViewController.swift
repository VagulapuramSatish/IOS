//
//  ViewController.swift
//  Vagulapuram_FormatName
//
//  Created by Vagulapuram,Satish on 2/3/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func initialsLabel(_ sender: UIButton) {
        
        displayLabel.text = "Details"
        fullNameLabel.text = "Full Name : " + lastNameTextField.text! + ", " + firstNameTextField.text!
        
        initialsLabel.text = "Initials : " +  firstNameTextField.text![firstNameTextField.text!.startIndex].uppercased() + lastNameTextField.text![lastNameTextField.text!.startIndex].uppercased()
    }
    
    @IBAction func onClickOfReset(_ sender: UIButton) {
    
        firstNameTextField.text=""
        lastNameTextField.text=""
        displayLabel.text=""
        fullNameLabel.text=""
        initialsLabel.text=""
        firstNameTextField.becomeFirstResponder()
    }
}

