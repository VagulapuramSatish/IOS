//
//  ViewController.swift
//  Vagulapuram_Movies
//
//  Created by student on 4/28/22.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies_arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = movies_arr[indexPath.row].category
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Do any additional setup after loading the view.
        let transition = segue.identifier
        if transition == "movieSegue"{
            let output = segue.destination as! MoviesViewController
            output.movies_Arr = movies_arr[(genreTableView.indexPathForSelectedRow!.row)].movies
            output.title_1 = movies_arr[(genreTableView.indexPathForSelectedRow!.row)].category
        }
    }
    
    @IBOutlet weak var genreTableView: UITableView!
    
    var movies_arr = movies_list
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Movies App"
        genreTableView.delegate = self
        genreTableView.dataSource = self
    }
}

   

