//
//  MovieData.swift
//  Vagulapuram_Movies
//
//  Created by student on 4/28/22.
//

import Foundation
import UIKit

struct Movies {
    var title:String
    var image:UIImage
    var releasedYear:String
    var movieRating:String
    var boxOffice:String
    var moviePlot:String
    var cast:[String] = []
}

struct Genre {
    var category:String
    var movies = [Movies]()
}

let Genre_1 = Genre(category: "Thriller",
                   movies: [
                    Movies(title: "Deep Water", image: UIImage(named: "thriller1")!, releasedYear: "2022", movieRating: "8.6", boxOffice: "$48.9 billion", moviePlot: "A well-to-do husband who allows his wife to have affairs in order to avoid.", cast: ["Ben Affleck","Ana de Armas"]),
                    Movies(title: "Knives Out", image: UIImage(named: "thriller2")!, releasedYear: "2019", movieRating: "7.5", boxOffice: "$40 million", moviePlot: "The family of Harlan Thrombey, a wealthy mystery novel party.", cast: ["Daniel Craig","Ana de Armas"]),
                    Movies(title: "Enola Holmes", image: UIImage(named: "thriller3")!, releasedYear: "2020", movieRating: "6.6", boxOffice: "$58 million", moviePlot: "She is extremely intelligent, observant, and insightful, defying the social norms for women.", cast: ["Millie Bobby Brown","Henry Cavill"]),
                    Movies(title: "Gone Girl", image: UIImage(named: "thriller4")!, releasedYear: "2014", movieRating: "8.1", boxOffice: "$329.8 million", moviePlot: "On their fifth wedding anniversary, writing teacher Nick Dunne returns home.", cast: ["Ben Affleck","Rosamund Pike"]),
                    Movies(title: "Oldboy", image: UIImage(named: "thriller5")!, releasedYear: "2013", movieRating: "7.8", boxOffice: "$508 million", moviePlot: "In 1993, alcoholic advertising executive Joe Doucett (Brolin) gets drunk after losing a major.", cast: ["Josh Brolin","Elizabeth Olsen"])])

let Genre_2 = Genre(category: "Adventure",
                   movies: [
                    Movies(title: "Uncharted", image: UIImage(named: "adventure1")!, releasedYear: "2022", movieRating: "6.5", boxOffice: "676.8 million", moviePlot: "Brothers Sam and Nathan Nate Drake are caught by museum security trying to steal the first map.", cast: ["Tom Holland","Mark Wahlberg"]),
                    Movies(title: "The Batman", image: UIImage(named: "adventure2")!, releasedYear: "2022", movieRating: "8.1", boxOffice: "884.8 million", moviePlot: "On Halloween, Gotham City mayor Don Mitchell Jr. is murdered by a man.", cast: ["Robert Pattinson","Zoë Kravitz"]),
                    Movies(title: "Moonfall", image: UIImage(named: "adventure3")!, releasedYear: "2022", movieRating: "8.6", boxOffice: "774.9 million", moviePlot: "In 2011, astronauts Brian Harper, Jocinda Fowler and newcomer Marcus are on a Space.", cast: ["Halle Berry","Patrick Wilson"]),
                    Movies(title: "Spider-Man: No Way Home", image: UIImage(named: "adventure4")!, releasedYear: "2021", movieRating: "8.4", boxOffice: "984.8 million", moviePlot: "After Quentin Beck frames Peter Parker for his murder and reveals Parker's identity.", cast: ["Tom Holland","Zendaya"]),
                    Movies(title: "The Adam Project", image: UIImage(named: "adventure5")!, releasedYear: "2022", movieRating: "6.6", boxOffice: "88.9 million", moviePlot: "In the year 2050, fighter pilot Adam Reed steals a time jet and escapes.", cast: ["Ryan Reynolds","Mark Ruffalo","Jennifer Garner"])])

let Genre_3 = Genre(category: "Mystery",
                   movies: [
                    Movies(title: "Rebecca", image: UIImage(named: "mystery1")!, releasedYear: "2020", movieRating: "6.1", boxOffice: "$6.5 billion", moviePlot: "While working for Mrs. Van Hopper, in Monte Carlo, a young woman becomes acquainted.", cast: ["Lily James", "Armie Hammer"]),
                    Movies(title: "Reminiscence", image: UIImage(named: "mystery2")!, releasedYear: "2021", movieRating: "8.4", boxOffice: "$660.5 million,", moviePlot: "In the near future, climate change has caused the seas to rise and flood Miami.", cast: ["Hugh Jackman","Rebecca Ferguson"]),
                    Movies(title: "Murder Mystery", image: UIImage(named: "mystery3")!, releasedYear: "2019", movieRating: "6.5", boxOffice: "$60.5 million", moviePlot: "Nick Spitz is a New York police officer, and his wife Audrey is a hairdresser.", cast: ["Adam Sandler","Jennifer Aniston"]),
                    Movies(title: "Mirage", image: UIImage(named: "mystery4")!, releasedYear: "2018", movieRating: "8.8", boxOffice: "80.8 million", moviePlot: "In 1989, during the fall of the Berlin Wall and a 72-hour-long electrical storm, a boy named Nico.", cast: ["Adriana Ugarte","Chino Darín"]),
                    Movies(title: "Shutter Island", image: UIImage(named: "mystery5")!, releasedYear: "2010", movieRating: "9.4", boxOffice: "9.8 billion", moviePlot: "In 1954, U.S. Marshal Edward Teddy Daniels and his new partner.", cast: ["Leonardo DiCaprio","Mark Ruffalo","Ben Kingsley"])])


let movies_list = [Genre_1,Genre_2,Genre_3]
