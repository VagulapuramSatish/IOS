//
//  ViewController.swift
//  Vagulapuram_Calculator
//
//  Created by Vagulapuram,Satish on 2/16/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var DisplayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
  
    
    @IBAction func buttonAC(_ sender: UIButton) {
    }
    
    @IBAction func buttonC(_ sender: UIButton) {
    }
    
    @IBAction func buttonChangeSign(_ sender: UIButton) {
    }
    
    @IBAction func buttonDivideSign(_ sender: UIButton) {
    }
    
    @IBAction func button7(_ sender: UIButton) {
    }
    
    @IBAction func button8(_ sender: UIButton) {
    }
    
    @IBAction func button9(_ sender: UIButton) {
    }
    
    @IBAction func buttonMultiplicationSign(_ sender: UIButton) {
    }
    
    @IBAction func button4(_ sender: UIButton) {
    }
    
    @IBAction func button5(_ sender: UIButton) {
    }
    
    @IBAction func button6(_ sender: UIButton) {
    }
    
    @IBAction func buttonSubtractSign(_ sender: UIButton) {
    }
    
    @IBAction func button1(_ sender: UIButton) {
    }
    
    @IBAction func button2(_ sender: UIButton) {
    }
    
    @IBAction func button3(_ sender: UIButton) {
    }
    
    @IBAction func buttonAdditionSign(_ sender: UIButton) {
    }
    
    @IBAction func button0(_ sender: UIButton) {
    }
    
    @IBAction func buttonDotSign(_ sender: UIButton) {
    }
    
    @IBAction func buttonModSign(_ sender: UIButton) {
    }
    
    @IBAction func buttonEqualsSign(_ sender: UIButton) {
    }
}

